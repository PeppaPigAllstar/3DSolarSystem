/**
 * @fileoverview Pluto Object
 * @author Hussain Raza <hraza8@gatech.edu>
 * @author Isaac Naupa <iaguirre6@gatech.edu>
 * @version 1.3
 */
var pluto = new Planet(1.3019e22,4.43682e12,7.37593e12,4743,1.1883e6,'https://PeppaPigAllstar.github.io/DemoJSON/pluto.jpg');
