/**
 * @fileoverview Jupiter Object
 * @author Hussain Raza <hraza8@gatech.edu>
 * @author Isaac Naupa <iaguirre6@gatech.edu>
 * @version 1.3
 */
var jupiter = new Planet(1.8982e27,740.52e9,816.62e9,13070,69.911e6,'https://PeppaPigAllstar.github.io/DemoJSON/jupiter.png');
