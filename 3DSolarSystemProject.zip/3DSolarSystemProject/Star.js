/**
 * @fileoverview Sun Object
 * @author Hussain Raza <hraza8@gatech.edu>
 * @author Isaac Naupa <iaguirre6@gatech.edu>
 * @version 1.3
 */
var sun = new Planet(1.9884e30,0,0,0,696.34e6,'https://PeppaPigAllstar.github.io/DemoJSON/sun%20(1).png');
