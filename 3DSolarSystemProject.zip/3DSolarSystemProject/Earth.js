/**
 * @fileoverview Earth Object
 * @author Hussain Raza <hraza8@gatech.edu>
 * @author Isaac Naupa <iaguirre6@gatech.edu>
 * @version 1.3
 */
var earth = new Planet(5.9724e24,147095000000,152100000000,29780,6.3710e6,'https://PeppaPigAllstar.github.io/DemoJSON/Earth.png');
