/**
 * @fileoverview Venus Object
 * @author Hussain Raza <hraza8@gatech.edu>
 * @author Isaac Naupa <iaguirre6@gatech.edu>
 * @version 1.3
 */
var venus = new Planet(4.8675e24,-107477000000,-108939000000,35020,6.0528e6,'https://PeppaPigAllstar.github.io/DemoJSON/Venus.jpg');
